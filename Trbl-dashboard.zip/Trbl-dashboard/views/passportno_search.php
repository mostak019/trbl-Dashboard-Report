<?php require_once APPPATH.'modules/common/header.php'; ?>
<div class="wrapper row-offcanvas row-offcanvas-left">
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="left-side sidebar-offcanvas">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
            <!-- Sidebar user panel -->
            <div class="user-panel">
                <div class="pull-left image">
                    <img src="<?php echo base_url(); ?>assets/img/avatar3.png" class="img-circle" alt="User Image" />
                </div>
                <div class="pull-left info">
                    <p>Hello! <?php echo $this->session->userdata('active_admin_name'); ?></p>
                    <p><?php echo date("F d, Y"); ?></p>
                </div>
            </div>
            <!-- sidebar menu: : style can be found in sidebar.less -->
            <?php require_once APPPATH.'modules/common/sidebar.php'; ?>
        </section>
        <!-- /.sidebar -->
    </aside>

	<!-- Right side column. Contains the navbar and content of the page -->
    <aside class="right-side">
        <!-- Content Header (Page header) -->
         <section class="content-header">
            Dashboard <span class="seperator"><i class="fa fa-angle-right"></i></span> Invoice List 
        </section>
        <div class="box">
        <div class="box-body table-responsive">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Passport No</th>
                        <th>Invoice No</th>
                        <th>Invoice Category</th>
                        <th>Invoice Date</th>
                        <th>Client Name</th>                       
                        <th>Client Mobile</th>                       
                    </tr>
                </thead>
                <tbody>
                  
                  <?php foreach ($passport_list as $key => $value) {?>
                      <tr>
                          <td><?=$value['passport_passport_no']?></td>
                          <td><?=$value['invoice_no']?></td>
                          <td><?=$value['invcat_title']?></td>
                          <td><?=$value['invoice_date']?></td>
                          <td><?=$value['client_name']?></td>                        
                          <td>
                            <?php
                            $client_mobile = json_decode($value['client_mobile']);
                            
                            $new_array = array();
                            foreach ($client_mobile as $key => $mbl_numbers) {
                                $new_array[] = $mbl_numbers[0].$mbl_numbers[1];
                            }
                            echo implode(', ', $new_array)
                            ?>  
                          </td>                       
                      </tr>
                 <?php }?>
                </tbody>
            </table>
        </div>
    </div>
    </aside>   
<?php require_once APPPATH.'modules/common/footer.php'; ?>