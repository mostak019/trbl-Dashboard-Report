<?php require_once APPPATH.'modules/common/header.php'; ?>
<div class="wrapper row-offcanvas row-offcanvas-left">
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="left-side sidebar-offcanvas">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
            <!-- Sidebar user panel -->
            <div class="user-panel">
                <div class="pull-left image">
                    <img src="<?php echo base_url(); ?>assets/img/avatar3.png" class="img-circle" alt="User Image" />
                </div>
                <div class="pull-left info">
                    <p>Hello! <?php echo $this->session->userdata('active_admin_name'); ?></p>
                    <p><?php echo date("F d, Y"); ?></p>
                </div>
            </div>
            <!-- sidebar menu: : style can be found in sidebar.less -->
            <?php require_once APPPATH.'modules/common/sidebar.php'; ?>
        </section>
        <!-- /.sidebar -->
    </aside>

	<!-- Right side column. Contains the navbar and content of the page -->
    <aside class="right-side">
        <!-- Content Header (Page header) -->
         <section class="content-header">
            Dashboard <span class="seperator"><i class="fa fa-angle-right"></i></span> Birthday List 
        </section>
        <div class="box">
        <div class="box-body table-responsive">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Birth Date</th>
                        <th>Send Sms</th>
                    </tr>
                </thead>
                <tbody>
                  
                  <?php foreach ($client_birthday_list as $key => $value) {?>
                      <tr>
                          <td><?=$value['client_name']?></td>
                          <td>
                          	<?php
                            $client_mobile = json_decode($value['client_mobile']);
                            
                          	$new_array = array();
                          	foreach ($client_mobile as $key => $mbl_numbers) {
                          		$new_array[] = $mbl_numbers[0].$mbl_numbers[1];
                          	}
                          	echo implode(', ', $new_array)
                          	?>	
                          </td>
                          <td><?=$value['client_email']?></td>
                          <td><?=$value['client_address']?></td>
                          <td><?=$value['client_date_of_birth']?></td>
                          <td><a class="btn btn-primary" href="<?php echo site_url('smscontroller/send_birthdaysms/'.$value['client_id']); ?>">Send Sms </a></td>
                      </tr>
                 <?php }?>
                </tbody>
            </table>
        </div>
    </div>
    </aside>   
<?php require_once APPPATH.'modules/common/footer.php'; ?>