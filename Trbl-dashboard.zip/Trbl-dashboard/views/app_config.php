<?php require_once APPPATH . 'modules/common/header.php'; ?>
<div class="wrapper row-offcanvas row-offcanvas-left">
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="left-side sidebar-offcanvas">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
            <!-- Sidebar user panel -->
            <div class="user-panel">
                <div class="pull-left image">
                    <img src="<?php echo base_url(); ?>assets/img/avatar3.png" class="img-circle" alt="User Image" />
                </div>
                <div class="pull-left info">
                    <p>Hello! <?php echo $this->session->userdata('active_admin_name'); ?></p>
                    <p><?php echo date("F d, Y"); ?></p>
                </div>
            </div>
            <!-- sidebar menu: : style can be found in sidebar.less -->
            <?php require_once APPPATH . 'modules/common/sidebar.php'; ?>
        </section>
        <!-- /.sidebar -->
    </aside>

    <!-- Right side column. Contains the navbar and content of the page -->
    <aside class="right-side">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            Dashboard <span class="seperator"><i class="fa fa-angle-right"></i></span> App Config <span class="seperator"><i class="fa fa-angle-right"></i></span> Edit App Config
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-lg-8">
                    <div class="box">
                        <div class="box-body set-position-relative">
                            <div class="loader disable-select" id="updatePassportloder"><img src="<?php echo base_url('assets/tools/loader.gif'); ?>" alt="Please Wait...." /></div>
                            <form action="javascript:void(0);" method="post" id="createForm" class="form-horizontal" enctype="multipart/form-data">
                                <div class="form-group">
                                    <div class="col-md-12" id="alertBox"></div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Company Name</label>
                                    <div class="col-md-7">
                                        <input name="company_info" type="text" id="company_info" class="form-control" placeholder="Name" value="<?=$trabill_app_config[0]['company_info']?>">

                                        <input name="id" type="hidden" class="form-control" value="<?=$trabill_app_config[0]['id']?>">

                                        <input name="pre_img" type="hidden" class="form-control" value="<?=$trabill_app_config[0]['logo']?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Company Phone</label>
                                    <div class="col-md-7">
                                        <input name="mobile" id="mobile" type="text" class="form-control" placeholder="Name" value="<?=$trabill_app_config[0]['mobile']?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Company Email</label>
                                    <div class="col-md-7">
                                        <input name="email" id="email" type="text" class="form-control" placeholder="Name" value="<?=$trabill_app_config[0]['email']?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Company Website</label>
                                    <div class="col-md-7">
                                        <input name="website" type="text" class="form-control" placeholder="Name" value="<?=$trabill_app_config[0]['website']?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Company Face Book Page</label>
                                    <div class="col-md-7">
                                        <input name="fb_page" type="text" class="form-control" placeholder="Face Book Page" value="<?=$trabill_app_config[0]['fb_page']?>">
                                    </div>
                                </div>

                                <!--<div class="form-group">-->
                                <!--    <label class="control-label col-md-3">Logo Style</label>-->
                                <!--    <div class="col-md-7">-->
                                <!--        <input name="logo_style" type="text" class="form-control" placeholder="Logo Style" value="<?=$trabill_app_config[0]['logo_style']?>">-->
                                <!--    </div>-->
                                <!--</div>-->

                                <div class="form-group">
                                    <label class="control-label col-md-3">Currency</label>
                                    <div class="col-md-7">
                                        <input name="currency" type="text" class="form-control" placeholder="Currency" value="<?=$trabill_app_config[0]['currency']?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-3">Data Base Backup Email</label>
                                    <div class="col-md-7">
                                        <input name="back_up_email" type="text" class="form-control" placeholder="Backup Email" value="<?=$trabill_app_config[0]['back_up_email']?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-3">Passport Limit</label>
                                    <div class="col-md-7">
                                        <input name="passport_limit" type="text" class="form-control" placeholder="Backup Email" value="<?=$trabill_app_config[0]['passport_limit']?>">
                                    </div>
                                </div>

                                 <div class="form-group">
                                    <label class="control-label col-md-3">User Limit</label>
                                    <div class="col-md-7">
                                        <input name="user_limit" type="text" class="form-control" placeholder="Backup Email" value="<?=$trabill_app_config[0]['user_limit']?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-3">Company Address 1</label>
                                    <div class="col-md-7">
                                        <textarea name="address" id="address" class="form-control summernote" cols="30" rows="7"><?=$trabill_app_config[0]['address']?></textarea>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-3">Company Address 2</label>
                                    <div class="col-md-7">
                                        <textarea name="address_two" id="address_two" class="form-control summernote" cols="30" rows="7"><?=$trabill_app_config[0]['address_two']?></textarea>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="control-label col-md-3">Logo Width</label>
                                    <div class="col-md-7">
                                        <input name="logo_width" type="number" class="form-control" value="<?=$trabill_app_config[0]['logo_width']?>">
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="control-label col-md-3">Logo height</label>
                                    <div class="col-md-7">
                                        <input name="logo_height" type="number" class="form-control" value="<?=$trabill_app_config[0]['logo_height']?>">
                                    </div>
                                </div>

                                 <div class="form-group">
                                    <label class="control-label col-md-3">Company Logo</label>
                                    <div class="col-md-7">
                                        <input name="logo" type="file" class="form-control" value="">
                                    </div>
                                </div>


                                <div class="modal-footer clearfix">
                                    <button type="submit" class="btn btn-primary btn-sm">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- /.content -->
    </aside>
    <!-- /.right-side -->
</div>
<!-- ./wrapper -->

<script type="text/javascript">
    $(document).ready(function () {
        $("#createForm").validate({
            rules: {
                passport_passport_no: {
                    required: true,
                },
                passport_name: {
                    required: true,
                },
                passport_mobile_no: {
                    required: true,
                },
            },
            messages: {

            },
            submitHandler: function () {
                var form_data = new FormData($("#createForm")[0]);
                    //console.log(form_data);

                        $.ajax({
                            url: "dashboard/update_company_info",
                            type: 'POST',
                            processData: false,
                            contentType: false,
                            cache: false,
                            enctype: 'multipart/form-data',
                            data: form_data,
                            success: function ( data ) {
                              var obj = JSON.parse(data);
                              if (obj.status == "ok")
                              {
                                $('#alertBox').html(obj.alert);
                                $('#updatePassportloder').hide();
                                $('html, body').animate({scrollTop: 0}, 1000);
                                return false;
                              } else
                              {
                                //have end check.
                              }
                               return false;
                               }
                        });
            }
        });
    });
</script>

<?php require_once APPPATH . 'modules/common/footer.php'; ?>