<?php require_once APPPATH.'modules/common/header.php'; ?>
<div class="wrapper row-offcanvas row-offcanvas-left">
	<!-- Left side column. contains the logo and sidebar -->
	<aside class="left-side sidebar-offcanvas">
		<!-- sidebar: style can be found in sidebar.less -->
		<section class="sidebar">
			<!-- Sidebar user panel -->
			<div class="user-panel">
				
				<div class="pull-left info">
					<p>Hello! <?php echo $this->session->userdata('active_admin_name'); ?></p>
					<p><?php echo date("F d, Y"); ?></p>
				</div>
			</div>
			<?php
			$invalied_invoice = $this->session->userdata('invalied_invoice');
			if ($invalied_invoice) {
				?>
				<div style="padding-left: 15px;color: red;"><?php echo $invalied_invoice; ?></div>
				<?php
				$this->session->unset_userdata('invalied_invoice');
			}
			?>
			<!-- sidebar menu: : style can be found in sidebar.less -->
			<?php require_once APPPATH.'modules/common/sidebar.php'; ?>
		</section>
		<!-- /.sidebar -->
	</aside>

	<!-- Right side column. Contains the navbar and content of the page -->
	<aside class="right-side">
		<!-- Content Header (Page header) -->
		<section class="content-header">                   
			Dashboard
		</section>

		<!-- Main content -->
		<section class="content">
			
				
				<div class="col-md-3">
					<div style="background: linear-gradient(90deg, rgba(0,57,237,1) 0%, rgba(107,107,246,1) 66%);">
						<?php $today_sales = $this->Dashboard_model->get_today_sales(); ?>
						<p style="margin: 0px;height: 40px;padding-top: 5px; font-size: 20px" class="text-center">Today's Sales</p>
					</div>
					<div class="bg-white">
						<p style="height: 60px;padding-top: 5px; font-size: 30px;" class="text-center"><b><?php echo number_format(floatval($today_sales), 2, '.', ','); ?></b></p>
					</div>
				</div>
				<div class="col-md-3">
					<div class="bg-primary">
						<?php $today_collections = $this->Dashboard_model->get_today_collections(); ?>
						<p style="margin: 0px;height: 40px;padding-top: 5px; font-size: 20px" class="text-center">"oday's Collection</p>
					</div>
					<div class="bg-white">
						<p style="height: 60px;padding-top: 5px; font-size: 30px;" class="text-center"><b><?php echo number_format(floatval($today_collections), 2, '.', ','); ?></b></p>
					</div>
				</div>
				<div class="col-md-3">
					<div class="bg-primary">
						<?php $today_expenses = $this->Dashboard_model->get_today_expenses(); ?>
						<p style="margin: 0px;height: 40px;padding-top: 5px; font-size: 20px" class="text-center">Today's Expenses</p>
					</div>
					<div class="bg-white">
						<p style="height: 60px;padding-top: 5px; font-size: 30px;" class="text-center"><b><?php echo number_format(floatval($today_expenses), 2, '.', ','); ?></b></p>
					</div>
				</div>
			
			<div class="col-md-9">
					<div id="container">
						<div id="graph1"></div>
					</div>
			</div>
			
			<div class="row">
				<div class="col-md-3">
					<div class="bg-primary">
						<?php $this_month_sales = $this->Dashboard_model->get_this_month_sales(); ?>
						<p style="margin: 0px;height: 40px;padding-top: 5px; font-size: 20px" class="text-center">This Month Sales</p>
					</div>
					<div class="bg-white">
						<p style="height: 60px;padding-top: 5px; font-size: 30px;" class="text-center"><b><?php echo number_format(floatval($this_month_sales), 2, '.', ','); ?></b></p>
					</div>
				</div>
				<div class="col-md-3">
					<div class="bg-primary">
						<?php $this_month_collections = $this->Dashboard_model->get_this_month_collections(); ?>
						<p style="margin: 0px;height: 40px;padding-top: 5px; font-size: 20px" class="text-center">This Month Collection</p>
					</div>
					<div class="bg-white">
						<p style="height: 60px;padding-top: 5px; font-size: 30px;" class="text-center"><b><?php echo number_format(floatval($this_month_collections), 2, '.', ','); ?></b></p>
					</div>
				</div>
				<div class="col-md-3">
					<div class="bg-primary">
						<?php $today_receivable = $this->Dashboard_model->get_total_receivable(); ?>
						<p style="margin: 0px;height: 40px;padding-top: 5px; font-size: 20px" class="text-center">Total Receivable</p>
					</div>
					<div class="bg-white">
						<p style="height: 60px;padding-top: 5px; font-size: 30px;" class="text-center"><b><?php echo number_format(floatval($today_receivable), 2, '.', ','); ?></b></p>
					</div>
				</div>
				<div class="col-md-3">
					<div class="bg-primary">
						<?php $today_payable = $this->Dashboard_model->get_total_payable(); ?>
						<p style="margin: 0px;height: 40px;padding-top: 5px; font-size: 20px" class="text-center">Total Payable</p>
					</div>
					<div class="bg-white">
						<p style="height: 60px;padding-top: 5px; font-size: 30px;" class="text-center"><b><?php echo number_format(floatval($today_payable), 2, '.', ','); ?></b></p>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-10">
					<div class="bg-primary text-center">
						<p style="margin: 0px;height: 35px;padding-top: 5px; font-size: 18px; padding-left: 20px">Current  Balance Status</p>
					</div>
					<div>
						<table class="table table-bordered">
						<thead>
							<tr>
								<th>SL</th>
								<th>Account Name</th>
								<th>Branch</th>
								<th>Account no</th>
								<th>Balance</th>
							</tr>
						</thead>
						<tbody>
							<?php 
								$accounts = $this->Dashboard_model->get_current_balance_status();
								$total_ac_balance = 0;
								if(count($accounts) !== 0):
								$sl = 1;
								foreach($accounts as $account):
								$total_ac_balance += $account['balance'];
							?>
							<tr>
								<td><?php echo $sl; ?></td>
								<td><?php echo $account['account_name']; ?></td>
								<td><?php echo $account['account_branch_name']; ?></td>
								<td><?php echo $account['account_number']; ?></td>
								<td>BDT <?php echo number_format(floatval($account['balance']), 2, '.', ','); ?></td>
							</tr>
							<?php 
								$sl++;
								endforeach; 
							?>
							<?php else: ?>
							<tr>
								<td colspan="5" class="text-center">No Data</td>
							</tr>
							<?php endif; ?>
							<tr>
								<td colspan="4" style=" text-align: right;">Total</td>
								<td><?php echo number_format(floatval($total_ac_balance), 2, '.', ','); ?></td>
							</tr>
						</tbody>
					</table>
					</div>
				</div>
				<div class="col-md-2">
					<div class="bg-primary">
						<?php $today_clients = $this->Dashboard_model->get_total_clients(); ?>
						<p style="margin: 0px;height: 30px;padding-top: 5px; font-size: 15px" class="text-center">Total Client</p>
					</div>
					<div class="bg-white">
						<p style="height: 40px;padding-top: 5px; font-size: 20px;" class="text-center">
						    <b>
						        <?php echo number_format(floatval($today_clients), 0, '.', ','); ?>
						    </b>
						</p>
					</div>
				</div>
				<div class="col-md-2">
					<div class="bg-primary">
						<?php $today_active_clients = $this->Dashboard_model->get_active_clients(); ?>
						<p style="margin: 0px;height: 30px;padding-top: 5px; font-size: 15px" class="text-center">Active Client</p>
					</div>
					<div class="bg-white">
						<p style="height: 40px;padding-top: 5px; font-size: 20px;" class="text-center"><b><?php echo number_format(floatval($today_active_clients), 0, '.', ','); ?></b></p>
					</div>
				</div>
				<div class="col-md-2">
					<div class="bg-primary">
						<?php $today_inactive_clients = $this->Dashboard_model->get_inactive_clients(); ?>
						<p style="margin: 0px;height: 30px;padding-top: 5px; font-size: 15px" class="text-center">Inactive Client</p>
					</div>
					<div class="bg-white">
						<p style="height: 40px;padding-top: 5px; font-size: 20px;" class="text-center"><b><?php echo number_format(floatval($today_inactive_clients), 0, '.', ','); ?></b></p>
					</div>
				</div>

			</div>
			<div class="row">

				<div class="col-md-6">
					<div class="bg-primary">
						<p style="margin: 0px;height: 35px;padding-top: 5px; font-size: 18px; padding-left: 20px">Last 5 Sales</p>
					</div>
					<div>
						<table class="table table-bordered">
						<thead>
							<tr>
								<th>SI</th>
								<th>Client Name</th>
								<th>Invoice Type</th>
								<th>Invoice No</th>
								<th>Amount</th>
								<th>Created By</th>
							</tr>
						</thead>
						<tbody>
							<?php 
								$invoices = $this->Dashboard_model->get_last_ten_sales();
								$total_sales = 0;
								if(count($invoices) !== 0):
								$sl = 1;
								foreach($invoices as $invoice):
								$total_sales += $invoice['invoice_net_total'];
							?>
							<tr>
								<td><?php echo $sl; ?></td>
								<td><?php echo $invoice['client_name']; ?></td>
								<td><?php echo $invoice['invcat_title']; ?></td>
								<td><?php echo $invoice['invoice_no']; ?></td>
								<td><?php echo number_format(floatval($invoice['invoice_net_total']), 2, '.', ','); ?></td>
								<td><?php echo $invoice['admin_full_name']; ?></td>
							</tr>
							<?php 
								$sl++;
								endforeach; 
							?>
							<?php else: ?>
							<tr>
								<td colspan="6" class="text-center">No Data</td>
							</tr>
							<?php endif; ?>
						</tbody>
					</table>
					</div>
				</div>

				<div class="col-md-6">
					<div class="bg-primary">
						<p style="margin: 0px;height: 35px;padding-top: 5px; font-size: 18px; padding-left: 20px">Last 5 Collection</p>
					</div>
						<div>
						<table class="table table-bordered">
						<thead>
							<tr>
								<th>SI</th>
								<th>Client Name</th>
								<th>Amount</th>
								<th>Method</th>
								<th>Received By</th>
							</tr>
						</thead>
						<tbody>
							<?php 
								$collections = $this->Dashboard_model->get_last_ten_collections();
								if(count($collections) !== 0):
								$sl = 1;
								foreach($collections as $collection):
							?>
							<tr>
								<td><?php echo $sl; ?></td>
								<td><?php echo $collection['client_name']; ?></td>
								<td><?php echo number_format(floatval($collection['receipt_total_amount']), 2, '.', ','); ?></td>
								<td><?php echo $collection['accategory_name']; ?></td>
								<td><?php echo $collection['admin_full_name']; ?></td>
							</tr>
							<?php 
								$sl++;
								endforeach; 
							?>
							<?php else: ?>
							<tr>
								<td colspan="5" class="text-center">No Data</td>
							</tr>
							<?php endif; ?>
						</tbody>
					</table>
					</div>
				</div>
				
			</div>

			<div class="row">

				<div class="col-md-6">
					<div class="bg-primary">
						<p style="margin: 0px;height: 35px;padding-top: 5px; font-size: 18px; padding-left: 20px">Last 5 Expenses</p>
					</div>
					<div>
						<table class="table table-bordered">
						<thead>
							<tr>
								<th>SI</th>
								<th>Head</th>
								<th>Sub Head</th>
								<th>Method</th>
								<th>Amount</th>
								
								
							</tr>
						</thead>
						<tbody>
							<?php 
								$expenses = $this->Dashboard_model->get_last_ten_expenses();
								if(count($expenses) !== 0):
								$sl = 1;
								foreach($expenses as $expense):
							?>
							<tr>
								<td><?php echo $sl; ?></td>
								<td><?php echo $expense['head_name']; ?></td>
								<td><?php echo $expense['subhead_name']; ?></td>
								<td><?php echo $expense['accategory_name']; ?></td>
								<td><?php echo number_format(floatval($expense['expdetails_amount']), 2, '.', ','); ?></td>
							</tr>
							<?php 
								$sl++;
								endforeach; 
							?>
							<?php else: ?>
							<tr>
								<td colspan="5" class="text-center">No Data</td>
							</tr>
							<?php endif; ?>
						</tbody>
					</table>
					</div>
				</div>

				<div class="col-md-6">
					<div class="bg-primary">
						<p style="margin: 0px;height: 35px;padding-top: 5px; font-size: 18px; padding-left: 20px">Last 5 Vendor Payment</p>
					</div>
					<div>
						<table class="table table-bordered">
						<thead>
							<tr>
								<th>SI</th>
								<th>Vendor Name</th>
								<th>Method</th>
								<th>Amount</th>
								
								
							</tr>
						</thead>
						<tbody>
							<?php 
								$payments = $this->Dashboard_model->get_last_ten_vendor_payments();
								if(count($payments) !== 0):
								$sl = 1;
								foreach($payments as $payment):
							?>
							<tr>
								<td><?php echo $sl; ?></td>
								<td><?php echo $payment['vendor_name']; ?></td>
								<td><?php echo $payment['accategory_name']; ?></td>
								<td><?php echo number_format(floatval($payment['vpay_amount']), 2, '.', ','); ?></td>
							</tr>
							<?php 
								$sl++;
								endforeach; 
							?>
							<?php else: ?>
							<tr>
								<td colspan="4" class="text-center">No Data</td>
							</tr>
							<?php endif; ?>
						</tbody>
					</table>
					</div>
				</div>
				
			</div>
			
			<div class="row">

				<div class="col-md-6">
					<div class="bg-primary">
						<p style="margin: 0px;height: 35px;padding-top: 5px; font-size: 18px; padding-left: 20px">Pending Cheques Of Customer</p>
					</div>
					<div>
						<ul class="nav nav-tabs" id="myTab" role="tablist">
						  <li class="nav-item active">
							<a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Today</a>
						  </li>
						  <li class="nav-item">
							<a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Tomorrow</a>
						  </li>
						</ul>
						<div class="tab-content">
						  <div class="tab-pane active" id="home" role="tabpanel" aria-labelledby="home-tab" style="padding: 15px 0;">
							<table class="table table-bordered">
								<thead>
									<tr>
										<th>SI</th>
										<th>Cheque Number</th>
										<th>Bank Name</th>
										<th>Withdraw Date</th>
										<th>Amount</th>
									</tr>
								</thead>
								<tbody>
									<?php 
										$today = date("Y-m-d");
										$customer_cheques = $this->Dashboard_model->get_pending_cheque_by_date($today);
										if(count($customer_cheques) !== 0):
										$sl = 1;
										foreach($customer_cheques as $cheque):
									?>
									<tr>
										<td><?php echo $sl; ?></td>
										<td><?php echo $cheque['cheque_number']; ?></td>
										<td><?php echo $cheque['cheque_bank_name']; ?></td>
										<td><?php echo date("d-m-Y", strtotime($cheque['cheque_withdraw_date'])); ?></td>
										<td><?php echo number_format(floatval($cheque['receipt_total_amount']), 2, '.', ','); ?></td>
									</tr>
									<?php 
										$sl++;
										endforeach; 
									?>
									<?php else: ?>
									<tr>
										<td colspan="5" class="text-center">No Data</td>
									</tr>
									<?php endif; ?>
								</tbody>
							</table>
						  </div>
						  <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab" style="padding: 15px 0;">
							<table class="table table-bordered">
								<thead>
									<tr>
										<th>SI</th>
										<th>Cheque Number</th>
										<th>Bank Name</th>
										<th>Withdraw Date</th>
										<th>Amount</th>
									</tr>
								</thead>
								<tbody>
									<?php 
										$tomorrow = date("Y-m-d", strtotime(date("Y-m-d").'+1 day'));
										$customer_cheques_tomorrow = $this->Dashboard_model->get_pending_cheque_by_date($tomorrow);
										if(count($customer_cheques_tomorrow) !== 0):
										$sl = 1;
										foreach($customer_cheques_tomorrow as $cheque):
									?>
									<tr>
										<td><?php echo $sl; ?></td>
										<td><?php echo $cheque['cheque_number']; ?></td>
										<td><?php echo $cheque['cheque_bank_name']; ?></td>
										<td><?php echo date("d-m-Y", strtotime($cheque['cheque_withdraw_date'])); ?></td>
										<td><?php echo number_format(floatval($cheque['receipt_total_amount']), 2, '.', ','); ?></td>
									</tr>
									<?php 
										$sl++;
										endforeach; 
									?>
									<?php else: ?>
									<tr>
										<td colspan="5" class="text-center">No Data</td>
									</tr>
									<?php endif; ?>
								</tbody>
							</table>
						  </div>
						</div>
					</div>
				</div>

				<div class="col-md-6">
					<div class="bg-primary">
						<p style="margin: 0px;height: 35px;padding-top: 5px; font-size: 18px; padding-left: 20px">Pending Payment Cheques</p>
					</div>
					<div>
						<ul class="nav nav-tabs" role="tablist">
						  <li class="nav-item active">
							<a class="nav-link active" id="ppcvToday-tab" data-toggle="tab" href="#ppcvToday" role="tab" aria-controls="home" aria-selected="true">Today</a>
						  </li>
						  <li class="nav-item">
							<a class="nav-link" id="ppcvTomorrow-tab" data-toggle="tab" href="#ppcvTomorrow" role="tab" aria-controls="profile" aria-selected="false">Tomorrow</a>
						  </li>
						</ul>
						<div class="tab-content">
						  <div class="tab-pane active" id="ppcvToday" role="tabpanel" aria-labelledby="ppcvToday-tab" style="padding: 15px 0;">
								<table class="table table-bordered">
									<thead>
										<tr>
											<th>SI</th>
											<th>Cheque Number</th>
											<th>Bank Name</th>
											<th>Withdraw Date</th>
											<th>Amount</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$today = date("Y-m-d");
											$others_cheques = $this->Dashboard_model->get_others_pending_cheque_by_date($today);
											if(count($others_cheques) !== 0):
											$sl = 1;
											foreach($others_cheques as $cheque):
										?>
										<tr>
											<td><?php echo $sl; ?></td>
											<td><?php echo $cheque['cheque_number']; ?></td>
											<td><?php echo $cheque['cheque_bank_name']; ?></td>
											<td><?php echo date("d-m-Y", strtotime($cheque['cheque_withdraw_date'])); ?></td>
											<td><?php echo number_format(floatval($cheque['cheque_amount']), 2, '.', ','); ?></td>
										</tr>
										<?php 
											$sl++;
											endforeach; 
										?>
										<?php else: ?>
										<tr>
											<td colspan="5" class="text-center">No Data</td>
										</tr>
										<?php endif; ?>
									</tbody>
								</table>
						  </div>
						  <div class="tab-pane fade" id="ppcvTomorrow" role="tabpanel" aria-labelledby="ppcvTomorrow-tab" style="padding: 15px 0;">
								<table class="table table-bordered">
									<thead>
										<tr>
											<th>SI</th>
											<th>Cheque Number</th>
											<th>Bank Name</th>
											<th>Withdraw Date</th>
											<th>Amount</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$tomorrow = date("Y-m-d", strtotime(date("Y-m-d").'+1 day'));
											$other_cheques_tomorrow = $this->Dashboard_model->get_others_pending_cheque_by_date($tomorrow);
											if(count($other_cheques_tomorrow) !== 0):
											$sl = 1;
											foreach($other_cheques_tomorrow as $cheque):
										?>
										<tr>
											<td><?php echo $sl; ?></td>
											<td><?php echo $cheque['cheque_number']; ?></td>
											<td><?php echo $cheque['cheque_bank_name']; ?></td>
											<td><?php echo date("d-m-Y", strtotime($cheque['cheque_withdraw_date'])); ?></td>
											<td><?php echo number_format(floatval($cheque['cheque_amount']), 2, '.', ','); ?></td>
										</tr>
										<?php 
											$sl++;
											endforeach; 
										?>
										<?php else: ?>
										<tr>
											<td colspan="5" class="text-center">No Data</td>
										</tr>
										<?php endif; ?>
									</tbody>
								</table>
						  </div>
						</div>
					</div>
				</div>
				
			</div>
			
			<div class="row">
				<div class="col-md-4">
					<div class="bg-primary">
						<p style="margin: 0px;height: 35px;padding-top: 5px; font-size: 18px; padding-left: 20px">Top 5 Source</p>
					</div>
					<div class="bg-white">
						<div class="row">
							<div class="col-md-6" style="padding-top: 10px;padding-left: 30px">
								<?php
								$top_source = $this->Dashboard_model->get_top_five_source();
								$arrayName = array('danger','primary','warning','success','danger');
								$main_total_src = array_sum(array_column($top_source, 'total_source'));
								foreach ($top_source as $key => $value) {?>

									<span><?=$value['source_title'];?></span>
									<div class="progress progress-xs" style="height: 7px;">
										<div class="progress-bar progress-bar-<?=$arrayName[$key]?> progress-bar-striped" role="progressbar" aria-valuenow="<?=($value['total_source']*100)/$main_total_src;?>" aria-valuemin="0" aria-valuemax="100" style="width: <?=($value['total_source']*100)/$main_total_src;?>%">
										</div>
									</div>
								<?php }?>

							</div>
							<div class="col-md-6 ">
								<div class="chart-responsive">
									<div class="chart" id="graph2" style="height: 250px;position: relative;"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="bg-primary">
						<p style="margin: 0px;height: 35px;padding-top: 5px; font-size: 18px; padding-left: 20px">Top 5 Highest Sales Product</p>
					</div>
					<div class="bg-white">
						<div class="row">
							<div class="col-md-6" style="padding-top: 10px;padding-left: 30px">
								<?php
								$top_sale_product = $this->Dashboard_model->get_top_five_highest_sales_product();
								$arrayName = array('success','danger','primary','warning','danger');
								$main_total_src = array_sum(array_column($top_sale_product, 'total_product'));
								foreach ($top_sale_product as $key => $value) {?>

									<span><?=$value['invcat_title'];?></span>
									<div class="progress progress-xs" style="height: 7px;">
										<div class="progress-bar progress-bar-<?=$arrayName[$key]?> progress-bar-striped" role="progressbar" aria-valuenow="<?=($value['total_product']*100)/$main_total_src;?>" aria-valuemin="0" aria-valuemax="100" style="width: <?=($value['total_product']*100)/$main_total_src;?>%">
										</div>
									</div>
								<?php }?>
							</div>
							<div class="col-md-6 ">
								<div class="chart-responsive">
									<div class="chart" id="graph3" style="height: 250px;position: relative;"></div>
								</div>

							</div>

						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="bg-primary">
						<p style="margin: 0px;height: 35px;padding-top: 5px; font-size: 18px; padding-left: 20px">Top 5 Client</p>
					</div>
					<div class="bg-white">
						<div class="row">
							<div class="col-md-6" style="padding-top: 10px;padding-left: 30px">
								<?php
								$top_client = $this->Dashboard_model->get_top_five_clients();
								$arrayName = array('success','danger','primary','warning','danger');
								$main_total_src = array_sum(array_column($top_client, 'total_client'));
								foreach ($top_client as $key => $value) {?>

									<span><?=$value['client_name'];?></span>
									<div class="progress progress-xs" style="height: 7px;">
										<div class="progress-bar progress-bar-<?=$arrayName[$key]?> progress-bar-striped" role="progressbar" aria-valuenow="<?=($value['total_client']*100)/$main_total_src;?>" aria-valuemin="0" aria-valuemax="100" style="width: <?=($value['total_client']*100)/$main_total_src;?>%">
										</div>
									</div>
								<?php }?>
							</div>
							<div class="col-md-6 ">
								<div class="chart-responsive">
									<div class="chart" id="graph4" style="height: 250px;position: relative;"></div>
								</div>

							</div>

						</div>
					</div>
				</div>
			</div>

			<script type="text/javascript">
				new Morris.Bar({
					element: 'graph1',
					data: [
					<?php
					$dt = new DateTime();
					$year = $dt->format('Y');

					for ($i=1; $i <= 12; $i++) { 
						$first_date = $year . "/" . sprintf("%02s", $i) . "/" . "01";
						$last_date = $year . "/" . sprintf("%02s", $i) . "/" . "31";

						$month = date("M", strtotime($first_date));
						$the_month = date("m", strtotime($first_date));
						$month_sales = $this->Dashboard_model->get_this_month_sales($the_month);
						$month_collections = $this->Dashboard_model->get_this_month_collections($the_month);
						$month_expenses = $this->Dashboard_model->get_this_month_expenses($the_month);
					?>
						{x: '<?=$month;?>', sales: <?php echo $month_sales ?>, collection:<?php echo $month_collections ?>, expenses:<?php echo $month_expenses ?>},
					<?php }?>
					
					],
					xkey: 'x',
					ykeys: ['sales', 'collection', 'expenses'],
					labels: ['Sales', 'Collection', 'Expenses'],
					xLabelAngle: 60,


				});

				new Morris.Donut({
					element: 'graph2',
					data: [
					<?php
					foreach ($top_source as $key => $value) {?>
						{label: "<?=$value['source_title'];?>", value: <?=$value['total_source'];?>},
					<?php }?>
					]
				});
				new Morris.Donut({
					element: 'graph3',
					data: [
					<?php
					foreach ($top_sale_product as $key => $value) {?>
						{label: "<?=$value['invcat_title'];?>", value: <?=$value['total_product'];?>},
					<?php }?>
					]
				});
				new Morris.Donut({
					element: 'graph4',
					data: [
					<?php foreach ($top_client as $key => $value) { ?>
						{label: "<?=$value['client_name'];?>", value: <?=$value['total_client'];?>},
					<?php }?>
					]
				});
			</script>
		</section><!-- /.content -->
	</aside><!-- /.right-side -->
</div><!-- ./wrapper -->
<?php require_once APPPATH.'modules/common/footer.php'; ?>