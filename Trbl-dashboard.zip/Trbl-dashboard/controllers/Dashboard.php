<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$active_admin = $this->session->userdata('active_admin');
		$loggedIn = $this->session->userdata('loggedIn');
		if($active_admin === null && $loggedIn !== TRUE)
		{
			redirect('login', 'refresh', true);
		}
		
		$this->load->model('Dashboard_model');
	}
	
	public function get_session_datas()
	{
		$all_data = $this->session->all_userdata();
		
		echo "<pre>";
		print_r($all_data);
		echo "</pre>";
	}
	
	public function index()
	{
		$this->load->view('index');
	}
	
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('login', 'refresh', true);
	}

	public function search(){

		$search_type = $this->input->post('search_type');

		$dob_day = $this->input->post('dob_day');
		$dob_month = $this->input->post('dob_month');

		$passport_exp_date = $this->input->post('passport_exp_date');
		$query = $this->input->post('query');
        
		if ($passport_exp_date) {
			$dateexplode = explode("-", $passport_exp_date);
			$first_date = $dateexplode[0];
			$last_date = $dateexplode[1];
		}
		$invoice_no = $this->input->post('invoice_no');

		if ($search_type == 'birthday') {
			$this->birthday_search($dob_day,$dob_month);
		}else if($search_type == 'passport_exp'){
			$this->passport_expiry($first_date,$last_date);
		}else if($search_type == 'invoice_no'){
            $this->invoice_search($query);
		}else if($search_type == 'passportNo'){
            $this->passportno_search($query);
		}
	}

	public function birthday_search($dob_day,$dob_month){
		$data['client_birthday_list']=$this->Dashboard_model->birthday_search($dob_day,$dob_month);       
		$this->load->view('dashboard/birthday_search', $data);
	}

	public function passport_expiry($first_date,$last_date){
		$data['passport_expire_date_by_daterange']=$this->Dashboard_model->get_passportexpire_date_by_daterange($first_date,$last_date);
		$this->load->view('dashboard/passport_expiry_search', $data);
	}

	public function invoice_search($invoice_no){
		$data['invoice_list']=$this->Dashboard_model->invoice_search($invoice_no);
		//echo "<pre>";print_r($data['invoice_list']);die();
		$this->load->view('dashboard/invoice_search', $data);
	}

	public function passportno_search($passport_no){
		$data['passport_list']=$this->Dashboard_model->passportno_search($passport_no);
		//echo "<pre>";print_r($data['invoice_list']);die();
		$this->load->view('dashboard/passportno_search', $data);
	}
	
		public function app_config(){
		$data['trabill_app_config']=get_info('trabill_app_config', 'id', 1);
		//echo "<pre>";print_r($data['trabill_app_config']);die();
		$this->load->view('dashboard/app_config', $data);
	}

	public function update_company_info() {
        $id = $this->input->post('id');
        
        $width = $this->input->post('logo_width');
        $height = $this->input->post('logo_height');
        
        $app_information = array(
            'company_info' => html_escape($this->input->post('company_info')),
            'mobile' => html_escape($this->input->post('mobile')),
            'email' => html_escape($this->input->post('email')),
            'website' => html_escape($this->input->post('website')),
            'fb_page' => html_escape($this->input->post('fb_page')),
//            'logo_style' => html_escape($this->input->post('logo_style')),
            'currency' => html_escape($this->input->post('currency')),
            'back_up_email' => html_escape($this->input->post('back_up_email')),
            'passport_limit' => html_escape($this->input->post('passport_limit')),
            'user_limit' => html_escape($this->input->post('user_limit')),
            'address' => $this->input->post('address'),
            'address_two' => $this->input->post('address_two'),
            'logo_width' => $width,
            'logo_height' => $height,
        );
        

        $pre_img = $this->input->post('pre_img');
        $app_information['logo'] = $pre_img;
        
        $success = '<div class="alert alert-success">App has been Updated!</div>';
        $result = array('status' => 'ok', 'alert' => $success);
        
        if($_FILES['logo']['error'] == 0){
            
            if (file_exists(FCPATH . 'uploads/company_info/' . $pre_img)) {
                $file_path = FCPATH . 'uploads/company_info/' . $pre_img;
                unlink($file_path);
                
                $thumb_image_path = FCPATH . 'uploads/company_info/thumbnail/' . $pre_img;
                unlink($thumb_image_path);
            }

            $config['upload_path'] = 'uploads/company_info/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size'] = 0;
            $config['max_width'] = 0;
            $config['max_height'] = 0;
            $config['remove_spaces'] = TRUE;
            $config['encrypt_name'] = TRUE;

            $this->load->library('image_lib');
            $this->load->library('upload', $config);

            if ( ! $this->upload->do_upload('logo')){
                $error = '<div class="alert alert-danger">'.$this->upload->display_errors().'</div>';
                $result = array('status' => 'error', 'alert' => $error);
            } else {
                $upload_data = $this->upload->data();

                $config2 = array();
                $config2['image_library'] = 'gd2';
                $config2['source_image'] = $upload_data['full_path'];
                $config2['new_image'] = 'uploads/company_info/thumbnail/' . $upload_data['file_name'];
                $config2['maintain_ratio'] = FALSE;
                $config2['width'] = $width;
                $config2['height'] = $height;

                $this->image_lib->initialize($config2);
                $this->image_lib->resize();

                $app_information['logo'] = $upload_data['file_name'];

            }
        }

        $this->Dashboard_model->update_app_config($app_information, $id);
        
        echo json_encode($result);
        exit;
    }
    
    public function change_password() {
        
        $data['admin_password'] = sha1(html_escape($this->input->post('n_password')));
		if($this->input->post('location') && $this->input->post('location') == 'u_list' && $this->input->post('uID'))
		{
			$admin_id = $this->input->post('uID');
		}else
		{
			$admin_id = $this->session->userdata('active_admin');
		}
        
        $this->Common_model->updateInfo('trabill_administrators', 'admin_id', $admin_id, $data);
        
        $alert = '<div class="alert alert-success">Password has been changed.</div>';
        $result = array('status' => 'ok', 'alert' => $alert);
        echo json_encode($result);
        exit;
    }
	
}
